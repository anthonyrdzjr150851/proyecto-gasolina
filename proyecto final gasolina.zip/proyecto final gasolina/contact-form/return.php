<?php

header("Status: 301 Moved Permanently");
header("Location: gasolina.html");
exit;

?>
